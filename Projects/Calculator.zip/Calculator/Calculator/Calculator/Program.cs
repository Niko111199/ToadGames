﻿using Calculator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        public static void Main(string[] args)
        {
            while (true)
            {
                CalculatePEMDAS calculator = new CalculatePEMDAS();
                if (calculator.Calculate(Console.ReadLine()))
                {
                    Console.WriteLine(calculator.GetResult());
                }
            }
        }
    }
}
