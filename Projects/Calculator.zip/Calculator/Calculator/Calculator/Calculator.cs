﻿using System;
using System.Text;
using System.Numerics;

namespace Calculator
{
    public partial class CalculatorCore
    {
        public int Add(int a, int b)
        {
            return a + b;
        }
        public int Sub(int a, int b)
        {
            return a - b;
        }
        public int Mul(int a, int b)
        {
            return a * b;
        }
        public int Div(int a, int b)
        {
            return a / b;
        }
    }
    public partial class CalculatorCore
    {
        public double Add(double a, double b)
        {
            return a + b;
        }
        public double Sub(double a, double b)
        {
            return a - b;
        }
        public double Mul(double a, double b)
        {
            return a * b;
        }
        public double Div(double a, double b)
        {
            return a / b;
        }
    }

    public class CalculateParser : CalculatorCore
    {
        protected string str = string.Empty; 
        protected char mathOperator = '+';   
        protected double finalResult;  
        protected int index = -1; 

        public double GetResult()
        {
            return finalResult;
        }
        public CalculateParser()
        {
            Init(string.Empty);
        }
        public void Init(string s)
        {
            str          = s;
            mathOperator = '+';
            finalResult  = 0;
            index        = -1;
        }
        public virtual bool Calculate(string s)
        {
            if (s is not null)
            {
                return ParseString(s);
            }
            return false;
        }
        protected bool ConvertString(int i)
        {

            if (index > -1)
            {
                double number;
                string substring = str.Substring(index, i - index);
             
                try
                {
                    number = Convert.ToDouble(substring);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: \"" + substring + "\"" + e.ToString());
                    return false;
                }
                switch (mathOperator)
                {
                    default:
                    case '+': finalResult = Add(finalResult, number); break;
                    case '-': finalResult = Sub(finalResult, number); break;
                    case '*': finalResult = Mul(finalResult, number); break;
                    case '/': finalResult = Div(finalResult, number); break;
                }
            }
         
            if (i < str.Length)
            {
                mathOperator = str[i];
                index = -1;
            }
            return true;
        }
        protected bool ParseString(string s)
        {
            Init(s);

            for (int i = 0; i < str.Length; i++)
            {
               if ((str[i] >= '0' && str[i] <= '9') || str[i] == ',')
                {   
                    if (index == -1)
                    {
                        index = i;
                    }
                }
                else
                if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/')
                { 
                    if (!ConvertString(i))
                    {
                        return false;
                    }
                }
            }
            
            if (index > -1)
            {
                if (!ConvertString(str.Length))
                {
                    return false;
                }
            }
            return true;
        }
    }

    public class CalculatePEMDAS : CalculateParser
    {
        public CalculatePEMDAS()
        {
            Init(string.Empty);
        }

        private bool EvaluateOperator(int index, char operation)
        {
            int prevOpIndex = GetIndexOfPreviousOperator(index);
            int nextOpIndex = GetIndexOfNextOperator(index);

            try
            {
                double leftOperand = Convert.ToDouble(str.Substring(prevOpIndex + 1, index - prevOpIndex - 1));
                double rightOperand = Convert.ToDouble(str.Substring(index + 1, nextOpIndex - index - 1));

                double result = operation switch
                {
                    '/' => Div(leftOperand, rightOperand),
                    '*' => Mul(leftOperand, rightOperand),
                };

                str = str.Substring(0, prevOpIndex + 1) + result.ToString() + str.Substring(nextOpIndex);
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error evaluating operator '{operation}': {e.Message}");
                return false;
            }
        }

        private int GetIndexOfPreviousOperator(int index)
        {
            for (int i = index - 1; i >= 0; i--)
            {
                if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/')
                {
                    return i;
                }
            }
            return -1;
        }

        private int GetIndexOfNextOperator(int index)
        {
            for (int i = index + 1; i < str.Length; i++)
            {
                if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/')
                {
                    return i;
                }
            }
            return str.Length;
        }

        private bool EvaluateParentheses()
        {
            while (str.Contains('('))
            {
                int closeIndex = str.IndexOf(')');
                if (closeIndex == -1)
                {
                    Console.WriteLine("Error: Mismatched parentheses.");
                    return false;
                }

                int openIndex = str.LastIndexOf('(', closeIndex);
                if (openIndex == -1)
                {
                    Console.WriteLine("Error: Mismatched parentheses.");
                    return false;
                }

                string subExpression = str.Substring(openIndex + 1, closeIndex - openIndex - 1);

                CalculatePEMDAS subCalculator = new CalculatePEMDAS();
                if (!subCalculator.Calculate(subExpression))
                {
                    return false;
                }

                str = str.Substring(0, openIndex) + subCalculator.GetResult().ToString() + str.Substring(closeIndex + 1);
            }
            return true;
        }

        public override bool Calculate(string s)
        {
            if (s == null)
            {
                Init(string.Empty);
                finalResult = 0;
                return false;
            }

            if (string.IsNullOrWhiteSpace(s))
            {
                Init(string.Empty);
                finalResult = 0;
                return true;
            }

            str = s;

            if (!EvaluateParentheses())
            {
                return false;
            }

            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == '/')
                {
                    if (!EvaluateOperator(i, '/'))
                    {
                        return false;
                    }
                    i = -1;
                }
            }

            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == '*')
                {
                    if (!EvaluateOperator(i, '*'))
                    {
                        return false;
                    }
                    i = -1;
                }
            }

            return base.ParseString(str);
        }
    }
}