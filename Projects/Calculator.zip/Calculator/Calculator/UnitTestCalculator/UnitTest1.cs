﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;
namespace UnitTestCalculator
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            CalculatorParser calculator = new CalculatorParser("-1+5");
            Assert.AreEqual(calculator.GetResult(), 4);
        }
    }
}
