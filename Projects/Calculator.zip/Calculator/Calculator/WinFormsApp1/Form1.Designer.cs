﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button0 = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            buttonSEP = new Button();
            buttonEQL = new Button();
            buttonADD = new Button();
            buttonSUB = new Button();
            buttonMUL = new Button();
            buttonDIV = new Button();
            label1 = new Label();
            buttonReset = new Button();
            buttonStartPar = new Button();
            buttonENDpar = new Button();
            SuspendLayout();
            // 
            // button0
            // 
            button0.BackColor = Color.White;
            button0.Cursor = Cursors.Hand;
            button0.FlatStyle = FlatStyle.Flat;
            button0.Font = new Font("Segoe UI", 11F);
            button0.Location = new Point(12, 236);
            button0.Name = "button0";
            button0.Size = new Size(94, 38);
            button0.TabIndex = 0;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = false;
            button0.Click += button0_Click;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 11F);
            button1.Location = new Point(12, 192);
            button1.Name = "button1";
            button1.Size = new Size(94, 38);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 11F);
            button2.Location = new Point(112, 192);
            button2.Name = "button2";
            button2.Size = new Size(94, 38);
            button2.TabIndex = 2;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Cursor = Cursors.Hand;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 11F);
            button3.Location = new Point(212, 192);
            button3.Name = "button3";
            button3.Size = new Size(94, 38);
            button3.TabIndex = 3;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 11F);
            button4.Location = new Point(12, 148);
            button4.Name = "button4";
            button4.Size = new Size(94, 38);
            button4.TabIndex = 4;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 11F);
            button5.Location = new Point(112, 148);
            button5.Name = "button5";
            button5.Size = new Size(94, 38);
            button5.TabIndex = 5;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Cursor = Cursors.Hand;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI", 11F);
            button6.Location = new Point(212, 148);
            button6.Name = "button6";
            button6.Size = new Size(94, 38);
            button6.TabIndex = 6;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Cursor = Cursors.Hand;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Segoe UI", 11F);
            button7.Location = new Point(12, 104);
            button7.Name = "button7";
            button7.Size = new Size(94, 38);
            button7.TabIndex = 7;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Cursor = Cursors.Hand;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Segoe UI", 11F);
            button8.Location = new Point(112, 104);
            button8.Name = "button8";
            button8.Size = new Size(94, 38);
            button8.TabIndex = 8;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Cursor = Cursors.Hand;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 11F);
            button9.Location = new Point(212, 104);
            button9.Name = "button9";
            button9.Size = new Size(94, 38);
            button9.TabIndex = 9;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // buttonSEP
            // 
            buttonSEP.Cursor = Cursors.Hand;
            buttonSEP.FlatStyle = FlatStyle.Flat;
            buttonSEP.Font = new Font("Segoe UI", 11F);
            buttonSEP.Location = new Point(112, 236);
            buttonSEP.Name = "buttonSEP";
            buttonSEP.Size = new Size(94, 38);
            buttonSEP.TabIndex = 10;
            buttonSEP.Text = ",";
            buttonSEP.UseVisualStyleBackColor = true;
            buttonSEP.Click += buttonSEP_Click;
            // 
            // buttonEQL
            // 
            buttonEQL.BackColor = Color.RoyalBlue;
            buttonEQL.Cursor = Cursors.Hand;
            buttonEQL.FlatStyle = FlatStyle.Flat;
            buttonEQL.Font = new Font("Segoe UI", 11F);
            buttonEQL.Location = new Point(212, 236);
            buttonEQL.Name = "buttonEQL";
            buttonEQL.Size = new Size(94, 38);
            buttonEQL.TabIndex = 11;
            buttonEQL.Text = "=";
            buttonEQL.UseVisualStyleBackColor = false;
            buttonEQL.Click += buttonEQL_Click;
            // 
            // buttonADD
            // 
            buttonADD.BackColor = Color.LightGray;
            buttonADD.Cursor = Cursors.Hand;
            buttonADD.FlatStyle = FlatStyle.Flat;
            buttonADD.Font = new Font("Segoe UI", 11F);
            buttonADD.Location = new Point(312, 236);
            buttonADD.Name = "buttonADD";
            buttonADD.Size = new Size(94, 38);
            buttonADD.TabIndex = 12;
            buttonADD.Text = "+";
            buttonADD.UseVisualStyleBackColor = false;
            buttonADD.Click += buttonADD_Click;
            // 
            // buttonSUB
            // 
            buttonSUB.BackColor = Color.LightGray;
            buttonSUB.Cursor = Cursors.Hand;
            buttonSUB.FlatStyle = FlatStyle.Flat;
            buttonSUB.Font = new Font("Segoe UI", 11F);
            buttonSUB.Location = new Point(312, 192);
            buttonSUB.Name = "buttonSUB";
            buttonSUB.Size = new Size(94, 38);
            buttonSUB.TabIndex = 13;
            buttonSUB.Text = "-";
            buttonSUB.UseVisualStyleBackColor = false;
            buttonSUB.Click += buttonSUB_Click;
            // 
            // buttonMUL
            // 
            buttonMUL.BackColor = Color.LightGray;
            buttonMUL.Cursor = Cursors.Hand;
            buttonMUL.FlatStyle = FlatStyle.Flat;
            buttonMUL.Font = new Font("Segoe UI", 11F);
            buttonMUL.Location = new Point(312, 148);
            buttonMUL.Name = "buttonMUL";
            buttonMUL.Size = new Size(94, 38);
            buttonMUL.TabIndex = 14;
            buttonMUL.Text = "*";
            buttonMUL.UseVisualStyleBackColor = false;
            buttonMUL.Click += buttonMUL_Click;
            // 
            // buttonDIV
            // 
            buttonDIV.BackColor = Color.LightGray;
            buttonDIV.Cursor = Cursors.Hand;
            buttonDIV.FlatStyle = FlatStyle.Flat;
            buttonDIV.Font = new Font("Segoe UI", 11F);
            buttonDIV.Location = new Point(312, 104);
            buttonDIV.Name = "buttonDIV";
            buttonDIV.Size = new Size(94, 38);
            buttonDIV.TabIndex = 15;
            buttonDIV.Text = "/";
            buttonDIV.UseVisualStyleBackColor = false;
            buttonDIV.Click += buttonDIV_Click;
            // 
            // label1
            // 
            label1.BackColor = Color.DimGray;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Segoe UI", 20F);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(394, 48);
            label1.TabIndex = 16;
            label1.Text = "0";
            label1.Click += label1_Click;
            // 
            // buttonReset
            // 
            buttonReset.BackColor = Color.DarkGray;
            buttonReset.Cursor = Cursors.Hand;
            buttonReset.FlatStyle = FlatStyle.Flat;
            buttonReset.Font = new Font("Segoe UI", 11F);
            buttonReset.Location = new Point(312, 60);
            buttonReset.Name = "buttonReset";
            buttonReset.Size = new Size(94, 38);
            buttonReset.TabIndex = 17;
            buttonReset.Text = "C";
            buttonReset.UseVisualStyleBackColor = false;
            buttonReset.Click += buttonReset_Click;
            // 
            // buttonStartPar
            // 
            buttonStartPar.BackColor = Color.LightGray;
            buttonStartPar.FlatStyle = FlatStyle.Flat;
            buttonStartPar.Font = new Font("Segoe UI", 11F);
            buttonStartPar.Location = new Point(112, 60);
            buttonStartPar.Name = "buttonStartPar";
            buttonStartPar.Size = new Size(94, 38);
            buttonStartPar.TabIndex = 18;
            buttonStartPar.Text = "(";
            buttonStartPar.UseVisualStyleBackColor = false;
            buttonStartPar.Click += buttonStartPar_Click;
            // 
            // buttonENDpar
            // 
            buttonENDpar.BackColor = Color.LightGray;
            buttonENDpar.FlatStyle = FlatStyle.Flat;
            buttonENDpar.Font = new Font("Segoe UI", 11F);
            buttonENDpar.Location = new Point(212, 60);
            buttonENDpar.Name = "buttonENDpar";
            buttonENDpar.Size = new Size(94, 38);
            buttonENDpar.TabIndex = 19;
            buttonENDpar.Text = ")";
            buttonENDpar.UseVisualStyleBackColor = false;
            buttonENDpar.Click += buttonENDpar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(415, 283);
            Controls.Add(buttonENDpar);
            Controls.Add(buttonStartPar);
            Controls.Add(buttonReset);
            Controls.Add(label1);
            Controls.Add(buttonDIV);
            Controls.Add(buttonMUL);
            Controls.Add(buttonSUB);
            Controls.Add(buttonADD);
            Controls.Add(buttonEQL);
            Controls.Add(buttonSEP);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(button0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MaximumSize = new Size(433, 330);
            MinimizeBox = false;
            MinimumSize = new Size(433, 330);
            Name = "Form1";
            Text = "Nikos Lommeregner";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button button0;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button buttonSEP;
        private Button buttonEQL;
        private Button buttonADD;
        private Button buttonSUB;
        private Button buttonMUL;
        private Button buttonDIV;
        private Label label1;
        private Button buttonReset;
        private Button buttonStartPar;
        private Button buttonENDpar;
    }
}
