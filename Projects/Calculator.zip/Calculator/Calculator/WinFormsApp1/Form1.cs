using Calculator;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        private CalculatePEMDAS cal;
        private bool reset;


        private void SetText(char c)
        {
            if (reset)
            {
                label1.Text = "";
                reset = false;
            }
            label1.Text += c;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                // Number keys (0-9)
                case Keys.D0:
                case Keys.NumPad0:
                    button0_Click(null, null);
                    break;
                case Keys.D1:
                case Keys.NumPad1:
                    button1_Click(null, null);
                    break;
                case Keys.D2:
                case Keys.NumPad2:
                    button2_Click(null, null);
                    break;
                case Keys.D3:
                case Keys.NumPad3:
                    button3_Click(null, null);
                    break;
                case Keys.D4:
                case Keys.NumPad4:
                    button4_Click(null, null);
                    break;
                case Keys.D5:
                case Keys.NumPad5:
                    button5_Click(null, null);
                    break;
                case Keys.D6:
                case Keys.NumPad6:
                    button6_Click(null, null);
                    break;
                case Keys.D7:
                case Keys.NumPad7:
                    button7_Click(null, null);
                    break;
                case Keys.D8:
                case Keys.NumPad8:
                    button8_Click(null, null);
                    break;
                case Keys.D9:
                case Keys.NumPad9:
                    button9_Click(null, null);
                    break;

                // Decimal point
                case Keys.Decimal:
                case Keys.OemPeriod:
                    buttonSEP_Click(null, null);
                    break;

                // Equals
                //case Keys.:
                case Keys.Enter:
                    buttonEQL_Click(null, null);
                    break;

                // Arithmetic operators
                case Keys.Add:
                case Keys.Oemplus: // '+'
                    buttonADD_Click(null, null);
                    break;
                case Keys.Subtract:
                case Keys.OemMinus: // '-'
                    buttonSUB_Click(null, null);
                    break;
                case Keys.Multiply:
                case Keys.Oem2:
                    buttonMUL_Click(null, null);
                    break;
                case Keys.Divide:// '/
                    buttonDIV_Click(null, null);
                    break;


                default:
                    return base.ProcessCmdKey(ref msg, keyData);
            }

            return true; // Indicate that the key press was handled
        }

        public Form1()
        {
            this.KeyPreview = true;
            InitializeComponent();
            cal = new CalculatePEMDAS();
            reset = true;
        }

        private void button0_Click(object sender, EventArgs e)
        {
            SetText('0');
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SetText('1');
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SetText('2');
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SetText('3');
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SetText('4');
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SetText('5');
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SetText('6');
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SetText('7');
        }

        private void button8_Click(object sender, EventArgs e)
        {
            SetText('8');
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SetText('9');
        }

        private void buttonSEP_Click(object sender, EventArgs e)
        {
            SetText(',');
        }

        private void buttonEQL_Click(object sender, EventArgs e)
        {

            cal.Calculate(label1.Text);
            label1.Text = cal.GetResult().ToString();

        }

        private void buttonADD_Click(object sender, EventArgs e)
        {
            SetText('+');
        }

        private void buttonSUB_Click(object sender, EventArgs e)
        {
            SetText('-');
        }

        private void buttonMUL_Click(object sender, EventArgs e)
        {
            SetText('*');
        }

        private void buttonDIV_Click(object sender, EventArgs e)
        {
            SetText('/');
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            reset = true;
            SetText('0');
            reset = true;
        }

        private void buttonStartPar_Click(object sender, EventArgs e)
        {
            SetText('(');
        }

        private void buttonENDpar_Click(object sender, EventArgs e)
        {
            SetText(')');
        }
    }
}
