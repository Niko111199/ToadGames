using Calculator;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TEST_INTEGR_IN_EXPRESSION()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("1+5"), true);
            Assert.AreEqual(calculator.GetResult(), 1 + 5);
        }
        [TestMethod]
        public void TEST_FLOAT_IN_EXPRESSION()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("1,0+5,0"), true);
            Assert.AreEqual(calculator.GetResult(), 1.0 + 5.0);
        }
        [TestMethod]
        public void TEST_SPACES_IN_EXPRESSION()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate(" 1 + 5 "), true);
            Assert.AreEqual(calculator.GetResult(), 1 + 5);
        }
        [TestMethod]
        public void TEST_NEGATIVE_NUMBER()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("-1+5"), true);
            Assert.AreEqual(calculator.GetResult(), -1 + 5);
        }
        [TestMethod]
        public void TEST_NEGATIVE_NUMBER_AND_SPACES()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("-1 + 5"), true);
            Assert.AreEqual(calculator.GetResult(), -1 + 5);
        }
        [TestMethod]
        public void TEST_MULTIPLE_OPERATORS()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("-1+5-2"),true);
            Assert.AreEqual(calculator.GetResult(), -1 + 5 - 2);
        }
        [TestMethod]
        public void TEST_MULTIPLE_OPERATORS_MULTIPLCATION()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("-1+5-2*10"), true);
            Assert.AreEqual(calculator.GetResult(), -1 + 5 - 2 * 10);
        }
        [TestMethod]
        public void TEST_MULTIPLE_OPERATORS_DIVISION()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("-1+5-2*10/2"), true);
            Assert.AreEqual(calculator.GetResult(), -1 + 5 - 2 * 10 / 2);
        }
        [TestMethod]
        public void TEST_MULTIPLE_OPERATORS_IN_CORRECT_ORDER()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("10/2*2-5-1"), true);
            Assert.AreEqual(calculator.GetResult(), 10 / 2 * 2 - 5 - 1);
        }
        [TestMethod]
        public void TEST_INVALID_CHARACTER()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate("-1+10f/2"), false);
            Assert.AreEqual(calculator.GetResult(), 0);
        }
        [TestMethod]
        public void TEST_EMPTY_STRING()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate(String.Empty), true);
            Assert.AreEqual(calculator.GetResult(), 0);
        }
        [TestMethod]
        public void TEST_NULL_STRING()
        {
            CalculatePEMDAS calculator = new CalculatePEMDAS();
            Assert.AreEqual(calculator.Calculate(null), false);
            Assert.AreEqual(calculator.GetResult(), 0);
        }
    }
}